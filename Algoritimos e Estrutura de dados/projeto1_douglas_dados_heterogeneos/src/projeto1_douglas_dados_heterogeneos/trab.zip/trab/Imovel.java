package projeto1_douglas_dados_heterogeneos;

public class Imovel {
	String nome;
	String tipo;
	int area;
	String localConstrucao;
	int anoConstrução;
	Construtor construtor;

}
