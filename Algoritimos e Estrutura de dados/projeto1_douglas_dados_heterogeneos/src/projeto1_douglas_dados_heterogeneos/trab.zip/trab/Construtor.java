package projeto1_douglas_dados_heterogeneos;

public class Construtor {
	String nome;
	long cpf;
	int idade;
	String naturalidade;
	

}
